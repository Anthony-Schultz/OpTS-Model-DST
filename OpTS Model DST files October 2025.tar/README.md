# fr-soil-depth
FR shiny app project

[![Rhino Test](https://github.com/joe-fennell/fr-soil-depth/actions/workflows/rhino-test.yml/badge.svg?branch=main)](https://github.com/joe-fennell/fr-soil-depth/actions/workflows/rhino-test.yml)

(R linter not used)