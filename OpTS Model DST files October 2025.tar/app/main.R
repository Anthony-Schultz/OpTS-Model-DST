box::use(
  shiny[NS, moduleServer, fluidPage, tags, reactiveVal, reactiveValues],
  shiny.fluent[fluentPage],
  shiny.router[router_ui, router_server, route],
  app / view / intro,
  app / view / input1,
  app / view / input2,
  app / view / input3,
  app / view / input4,
  app / view / input5,
  app / view / input6,
  app / view / input7,
  app / view / input8,
  app / view / results
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  tags$html(
    lang = "en", # Set the language attribute
    fluidPage(
      # fluentPage(
      tags$head(
        tags$title("Forest Research OpTS tool") # Add a title tag
      ),
      router_ui(
        route("/", intro$ui(ns("intro"))),
        route("input1", input1$ui(ns("input1"))),
        route("input2", input2$ui(ns("input2"))),
        route("input3", input3$ui(ns("input3"))),
        route("input4", input4$ui(ns("input4"))),
        route("input5", input5$ui(ns("input5"))),
        route("input6", input6$ui(ns("input6"))),
        route("input7", input7$ui(ns("input7"))),
        route("input8", input8$ui(ns("input8"))),
        route("results", results$ui(ns("results")))
      )
    )
  )
}

#' @export
server <- function(id) {
  moduleServer(id, function(input, output, session) {
    router_server("/")

    # define all input variables here
    input_values <- reactiveValues(
      osgb_grid_reference = NULL,
      topsoil_depth = NULL,
      topsoil_texture = NULL,
      topsoil_stone = NULL,
      sfm_texture = NULL,
      sfm_stone = NULL,
      sfm_prep = NULL,
      crop_type = NULL
    )
    # make a list of all pages
    # server needs to be instantiated for each.
    intro$server("intro")
    input1$server("input1", input_values)
    input2$server("input2", input_values)
    input3$server("input3", input_values)
    input4$server("input4", input_values)
    input5$server("input5", input_values)
    input6$server("input6", input_values)
    input7$server("input7", input_values)
    input8$server("input8", input_values)
    results$server("results", input_values)
  })
}
