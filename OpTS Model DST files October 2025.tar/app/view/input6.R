box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, reactiveVal, uiOutput, renderUI],
  shiny.fluent[Text, ChoiceGroup.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  app / logic / render[generate_error_message, generate_homepage_link, generate_error_prompt],
  app / logic / parse[validate_multiple_selection, parse_model_config_options]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  stone_levels_options <- parse_model_config_options("stone_levels")

  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("input5")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("6. What percentage of the soil-forming material is made up of stones?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p(
            "Select the estimated stoniness class for the soil-forming material currently on site,
            or to be added to the site prior to planting "
          ),
          h3("If the site falls into more than one class"),
          p(
            "We recommend estimating a higher stoniness class over a lower one."
          ),
          h3("If you don't know the stoniness class of the soil-forming material"),
          p(
            "Information on stoniness classes and how to estimate soil stoniness can be found in the ",
            generate_homepage_link(), "."
          ),
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        ChoiceGroup.shinyInput(
          inputId = ns("sfm_stone_input"),
          options = stone_levels_options,
          ariaLabelledBy = ns("question"),
          class = "custom-choice-group"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Continue",
          ariaLabel = "continue button",
          class = "custom-primary"
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # set up default empty error message
    output$error_message <- renderUI(NULL)

    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_multiple_selection(input$sfm_stone_input)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$sfm_stone <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$sfm_stone <- input$sfm_stone_input
        change_page("input7")
      }
    })
  })
}
