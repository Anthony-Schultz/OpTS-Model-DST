box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, reactiveVal, uiOutput, renderUI],
  shiny.fluent[Text, ChoiceGroup.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  app / logic / render[generate_error_message, generate_homepage_link, generate_error_prompt],
  app / logic / parse[validate_multiple_selection, parse_model_config_options]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  topsoil_thickness_options <- parse_model_config_options("top_thick_levels")

  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("input1")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("2. What will the topsoil thickness be on the site?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p("Select the topsoil thickness currently on site, or to be added to the site prior to planting."),
          h3("If there will be no topsoil on the site"),
          p("Select the 'No topsoil' option."),
          h3("If the site falls into more than one category or you do not know the topsoil thickness"),
          p(
            "Information on topsoil definitions and measuring guidance can be
            found in the ",
            generate_homepage_link(), "."
          )
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        ChoiceGroup.shinyInput(
          inputId = ns("soil_depth_input"),
          options = topsoil_thickness_options,
          ariaLabelledBy = ns("question"),
          class = "custom-choice-group"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Continue",
          ariaLabel = "continue button",
          class = "custom-primary"
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # set up default empty error message
    output$error_message <- renderUI(NULL)

    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_multiple_selection(input$soil_depth_input)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$topsoil_depth <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$topsoil_depth <- input$soil_depth_input
        # print(input$soil_depth_input)
        change_page("input3")
      }
    })
  })
}
