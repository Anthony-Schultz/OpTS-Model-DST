box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, reactiveVal, uiOutput, renderUI],
  shiny.fluent[Text, Dropdown.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  app / logic / render[generate_error_message, generate_homepage_link, generate_error_prompt],
  app / logic / parse[validate_topsoil_options, parse_model_config_options]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  topsoil_texture_options <- parse_model_config_options("soil_texture_classes", "No topsoil")

  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("input2")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("3. What will the texture of the topsoil be on the site?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p("Select the soil texture for topsoil currently on site, or to be added to the site prior to planting."),
          h3("If there will be no topsoil on the site"),
          p("Select the 'No topsoil' option."),
          h3("If you don't know the texture of the topsoil"),
          p(
            "Information on soil texture categories and identifying correct texture can be found in the ",
            generate_homepage_link(), "."
          )
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        Dropdown.shinyInput(
          inputId = ns("soil_texture_input"),
          options = topsoil_texture_options,
          ariaLabelledBy = ns("question"),
          class = "custom-choice-group"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Continue",
          ariaLabel = "continue button",
          class = "custom-primary"
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # set up default empty error message
    output$error_message <- renderUI(NULL)

    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_topsoil_options(input$soil_texture_input, input_values$topsoil_depth)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$topsoil_texture <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$topsoil_texture <- input$soil_texture_input
        change_page("input4")
      }
    })
  })
}
