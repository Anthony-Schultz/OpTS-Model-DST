box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, reactiveVal, uiOutput, renderUI],
  shiny.fluent[Text, ChoiceGroup.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  app / logic / render[generate_error_message, generate_homepage_link, generate_error_prompt],
  app / logic / parse[validate_multiple_selection, parse_model_config_options]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  crop_options <- parse_model_config_options("transpiration_rates")

  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("input7")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("8. What type of woodland will be planted?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p("Select the main type of tree (broadleaved or conifer) that will be planted. Select mixed when an equal amount of broadleaved and conifer will be planted."),
          h3("If you are unsure which option to select"),
          p(
            "Information on woodland and crop type can be found in the ",
            generate_homepage_link(), "."
          )
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        ChoiceGroup.shinyInput(
          inputId = ns("crop_input"),
          options = crop_options,
          ariaLabelledBy = ns("question"),
          class = "custom-choice-group"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Results",
          ariaLabel = "continue button",
          class = "custom-primary"
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # set up default empty error message
    output$error_message <- renderUI(NULL)
    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_multiple_selection(input$crop_input)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$crop_type <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$crop_type <- input$crop_input
        change_page("results")
      }
    })
  })
}
