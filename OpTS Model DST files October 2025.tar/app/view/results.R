box::use(
  shiny[div, NS, moduleServer, renderText, HTML, reactive, uiOutput, a, p, observeEvent, observe, renderPrint, reactiveValuesToList, reactiveVal, renderUI],
  shiny.fluent[Text, Stack, DefaultButton.shinyInput, reactOutput, PrimaryButton, renderReact],
  shiny.router[change_page, route_link],
  app / logic / parse[parse_inputs],
  app / logic / model[predict],
  app / logic / render[generate_certificate, generate_error_message, generate_homepage_url]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  Stack(
    class = "app-container",
    tokens = list(childrenGap = 15),
    children = list(
      a("< Back", href = route_link("input8")),
      uiOutput(ns("error_message")),
      reactOutput(ns("certificate")), # React output for the certificate
      p("This result may be printed or saved for future reference."),
      Stack(
        horizontal = TRUE,
        class = "app-container",
        horizontalAlign = "center", # Align items horizontally
        wrap = TRUE, # Allow wrapping into a vertical stack when space is limited
        tokens = list(childrenGap = 15),
        children = list(
          DefaultButton.shinyInput(
            inputId = ns("reset_btn"),
            text = "Start again",
            ariaLabel = "start again button",
            class = "custom-secondary"
          ),
          PrimaryButton(
            text = "Return to project page",
            href = generate_homepage_url(),
            class = "custom-primary",
            ariaLabel = "return to project page button"
          )
        )
      )
    )
  )
}

#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # Reactive value to track the model state
    result <- reactiveVal(NULL)

    # Reset button logic
    observeEvent(input$reset_btn, {
      change_page("/") # Navigate to the home page
      session$reload()
    })

    # constantly observing with an error thrown if inputs not complete
    observe({
      # Run the model and update the result
      tryCatch(
        {
          converted_inputs <- as.list(reactiveValuesToList(input_values))
          model_parameters <- do.call(parse_inputs, converted_inputs)
          outputs <- do.call(predict, model_parameters)
          cert <- generate_certificate(outputs, converted_inputs)
          result(cert) # Update the reactive result
          output$error_message <- renderText(NULL) # Clear any previous error message
        },
        error = function(e) {
          # Set an error message if something fails
          output$error_message <- renderUI(generate_error_message(
            'Something went wrong. Please click the "Start again" button below to restart.'
          ))
          result(NULL)
        }
      )
    })

    # Render the certificate
    output$certificate <- renderReact({
      cert <- result()
      if (is.null(cert)) {
        return(NULL)
      }
      cert
    })
  })
}
