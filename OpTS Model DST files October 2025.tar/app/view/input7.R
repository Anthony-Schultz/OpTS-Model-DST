box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, strong, reactiveVal, uiOutput, renderUI],
  shiny.fluent[Text, ChoiceGroup.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  app / logic / render[generate_error_message, generate_homepage_link, generate_error_prompt],
  app / logic / parse[validate_multiple_selection, parse_model_config_options]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  prep_options <- parse_model_config_options("soil_prep_levels")

  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("input6")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("7. How will the soil-forming material be prepared?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p("Select whether the site will be prepared by deep ripping or loose tipping of soil-forming material."),
          h3("If you are unsure which method applies to your site"),
          p(
            strong("Deep ripping"), " is a process of intensive soil tillage that involves mechanically
            breaking up compacted soil layers to improve soil structure and aeration."
          ),
          p(
            strong("Loose tipping"), " is a technique where soils are deposited on-site without
            the use of heavy machinery driving over them, which helps to minimise soil compaction during placement."
          ),
          p(
            "Information on site preparation techniques can be found in the ",
            generate_homepage_link(), "."
          )
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        ChoiceGroup.shinyInput(
          inputId = ns("prep_input"),
          options = prep_options,
          ariaLabelledBy = ns("question"),
          class = "custom-choice-group"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Continue",
          ariaLabel = "continue button",
          class = "custom-primary"
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    # set up default empty error message
    output$error_message <- renderUI(NULL)

    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_multiple_selection(input$prep_input)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$sfm_prep <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$sfm_prep <- input$prep_input
        change_page("input8")
      }
    })
  })
}
