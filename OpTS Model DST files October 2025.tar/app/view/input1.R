box::use(
  shiny[div, observeEvent, NS, moduleServer, reactive, tags, HTML, observe, h2, h3, p, a, reactiveVal, uiOutput, renderUI, req],
  shiny.fluent[Text, TextField.shinyInput, PrimaryButton.shinyInput, Stack, FocusZone],
  shiny.router[change_page, route_link],
  leaflet[leafletOutput, renderLeaflet, leaflet, addTiles, addMarkers, setView, leafletOptions, clearMarkers, leafletProxy, flyTo, addAwesomeMarkers, awesomeIcons],
  app / logic / render[generate_error_message, generate_OSGB_tool_link, generate_error_prompt],
  app / logic / parse[validate_osgb_input, parse_model_config_options],
  app / logic / osgb[osg_parse]
)

#' @export
ui <- function(id) {
  ns <- NS(id)
  # Wrapping primary content in a <main> tag
  tags$main(
    id = ns("main-content"), # Adding an ID for the main tag
    `aria-live` = "polite", # Enable live region to announce updates
    Stack(
      class = "app-container",
      tokens = list(childrenGap = 15),
      children = list(
        # Leave this in and update to desired back page
        a("< Back", href = route_link("/")),
        # Always leave this in
        uiOutput(ns("error_message")),
        # Always use h1 for the main question
        h2("1. What is the location of the site you are assessing?",
          id = ns("question")
        ),
        # Always use the explainer div to provide more info
        div(
          p(
            "Enter the site location as an Ordnance Survey six-figure grid reference.
            This is two letters followed by six numbers, for example: TQ123456 ."
          ),
          h3("If you do not already know the Ordnance Survey six-figure grid reference"),
          p(
            "You can find this by using a third-party, online tool, such as this one: ",
            generate_OSGB_tool_link()
          ),
          p(
            "You can confirm the site is the one you intended using the map below."
          )
        ),
        uiOutput(ns("error_prompt")),
        # This is where the input objects go:
        TextField.shinyInput(
          inputId = ns("osgb_grid_reference"),
          ariaLabel = "OSGB 6-digit grid reference" # ,
          # class = "input-text-box"
        ),
        # Finally, this is the continue section
        PrimaryButton.shinyInput(
          inputId = ns("continue_btn"),
          text = "Continue",
          ariaLabel = "continue button",
          class = "custom-primary"
        ),
        div(
          leafletOutput(ns("map"), width = "auto"),
          `aria-label` = "Zoomable map showing the position of the site on a map",
          role = "application"
        ),
        div(
          HTML('Map powered by <a href="https://leafletjs.com/" target="_blank">Leaflet</a> |
          Data by <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>')
        )
      )
    )
  )
}


#' @export
server <- function(id, input_values) {
  moduleServer(id, function(input, output, session) {
    icons <- awesomeIcons(
      icon = "glyphicon-tree-deciduous",
      library = "glyphicon",
      iconColor = "white",
      markerColor = "black"
    )
    # set up default empty error message
    output$error_message <- renderUI(NULL)

    # Initialize the map with a default UK view
    output$map <- renderLeaflet({
      leaflet(options = leafletOptions(attributionControl = FALSE)) |>
        addTiles() |>
        setView(lng = -1.5, lat = 54.0, zoom = 5) # UK-focused zoom level
    })

    # generate var to hold position
    parsed <- reactive({
      if (is.null(input$osgb_grid_reference)) {
        return(NULL)
      }
      if (nchar(input$osgb_grid_reference) == 8) {
        tryCatch(
          {
            return(osg_parse(input$osgb_grid_reference, coord_system = "WGS84"))
          },
          error = function(e) {
            NULL
          }
        )
      } else {
        return(NULL)
      }
    })
    # user updates coordinates
    observe({
      coords <- parsed()
      if (!is.null(coords)) {
        # Use leafletProxy to update the map without reinitializing
        leafletProxy("map") |>
          clearMarkers() |>
          addAwesomeMarkers(
            data = data.frame(lon = coords$x, lat = coords$y),
            ~lon, ~lat, label = "Site Location", icon = icons
          ) |>
          flyTo(lng = coords$x, lat = coords$y, zoom = 10, options = list(duration = .3))
      } else {
        # Reset to original view and clear markers
        leafletProxy("map") |>
          clearMarkers() # |>
        # setView(lng = -1.5, lat = 54.0, zoom = 4) # Default UK-focused view
      }
    })

    # user attempts to change the page to the next page.
    observeEvent(input$continue_btn, {
      validation_error <- validate_osgb_input(input$osgb_grid_reference)
      if (!is.null(validation_error)) {
        # set error message and update var to NULL
        output$error_message <- renderUI(generate_error_message(validation_error))
        output$error_prompt <- renderUI(generate_error_prompt(validation_error))
        input_values$osgb_grid_reference <- NULL
      } else {
        # clear the error message
        output$error_message <- renderUI(NULL)
        output$error_prompt <- renderUI(NULL)
        input_values$osgb_grid_reference <- input$osgb_grid_reference
        change_page("input2")
      }
    })
  })
}
