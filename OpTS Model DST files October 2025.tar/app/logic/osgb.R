# convert OS GB grid reference to lon lat
box::use(
  terra
)
#'   osg_parse(grid_refs = "TQ722213","SN831869","SN829838")
#' @export
osg_parse <- function(grid_refs, coord_system = c("BNG", "WGS84")) {
  grid_refs <- toupper(as.character(grid_refs))
  coord_system <- match.arg(coord_system)

  if (!grepl("^[A-Z]{2}\\d{6}$", grid_refs)) {
    stop("Enter two letters followed by six numbers.")
  }

  epsg_out <- unname(c("BNG" = 27700, "WGS84" = 4326)[coord_system])
  names.out <- list("BNG" = c("easting", "northing"), "WGS84" = c("lon", "lat"))[[coord_system]]

  letter <- strsplit(substr(grid_refs, 1L, 2L), split = "", fixed = TRUE)
  letter <- do.call(rbind, letter)

  # Ireland has a different CRS
  epsg_source <- 27700

  # First letter identifies the 500x500 km grid
  offset1 <- list(
    "S" = c(x = 0, y = 0), "T" = c(5, 0),
    "N" = c(0, 5), "H" = c(0, 10),
    "O" = c(5, 5), "I" = c(0, 0)
  )
  offset1 <- do.call(rbind, offset1)

  # Second letter identifies the 100x100 km grid
  offset2 <- list(
    "A" = c(y = 4, x = 0), "B" = c(4, 1), "C" = c(4, 2), "D" = c(4, 3),
    "E" = c(4, 4), "F" = c(3, 0), "G" = c(3, 1), "H" = c(3, 2),
    "J" = c(3, 3), "K" = c(3, 4), "L" = c(2, 0), "M" = c(2, 1),
    "N" = c(2, 2), "O" = c(2, 3), "P" = c(2, 4), "Q" = c(1, 0),
    "R" = c(1, 1), "S" = c(1, 2), "T" = c(1, 3), "U" = c(1, 4),
    "V" = c(0, 0), "W" = c(0, 1), "X" = c(0, 2), "Y" = c(0, 3),
    "Z" = c(0, 4)
  )
  offset2 <- do.call(rbind, offset2)[, c("x", "y")]

  if (!all(letter[, 1] %in% rownames(offset1)) || !all(letter[, 2] %in% rownames(offset2))) {
    stop("Incorrect grid letters in grid reference. Enter a valid grid reference.")
  }

  offset <- offset1[letter[, 1], , drop = FALSE] +
    offset2[letter[, 2], , drop = FALSE]

  padz <- function(x, n = max(nchar(x))) gsub(" ", "0", formatC(x, width = -n))

  # Extract x and y parts, pad with trailing zeros if precision is low
  n <- nchar(grid_refs) - 2
  x <- paste0(offset[, "x"], padz(substr(grid_refs, 3, (n / 2) + 2), n = 5))
  y <- paste0(
    offset[, "y"],
    padz(substr(grid_refs, (n / 2) + 3, n + 2), n = 5)
  )

  if (any(is.na(c(x, y)))) {
    stop("An unexpected error occurred.")
  }

  xy <- .transform_crs(
    x = as.numeric(x), y = as.numeric(y),
    from = epsg_source, to = epsg_out
  )

  return(xy)

  # return(as.list(xy))
}

.transform_crs <- function(x, y, from, to) {
  if (!is.numeric(x) || !is.numeric(y)) {
    stop("Coordinates x and y must be numeric.")
  }

  # Create points in the source CRS
  points <- terra::vect(cbind(x, y), crs = paste0("EPSG:", from))

  # Reproject the points to the target CRS
  points_transformed <- terra::project(points, paste0("EPSG:", to))

  # Extract transformed coordinates
  coords <- terra::geom(points_transformed)

  # Return the transformed coordinates as a data frame
  return(list(x = coords[3], y = coords[4]))
}
