box::use(
  shiny[div, tags, HTML, observe, h1, h2, h3, span, p, a, strong, tagList],
  shiny.fluent[Stack],
  app / logic / io[MODEL_CONFIG]
)

#' @export
generate_certificate <- function(output_values, input_raw) {
  # Title text
  title_text <- div(h2("OpTS assessment result"), class = "certificate-header neutral")

  # headline result
  result_headline_text <- div(
    h3("Site result"),
    .generate_headline(output_values),
    p("Refer to the general guidance below.")
  )
  # Input parameters section
  input_params_text <- div(
    h3("About the site"),
    p("You told us:"),
    # list of input properties
    .generate_soil_info(output_values, input_raw)
  )

  result_long_text <- div(
    h3("About the result"),
    p(
      "Climate projections were used to estimate the annual growing period (April-September) rainfall in different time periods.
      This was used to calculate the amount of soil-forming material that would be needed to meet the water
      requirements for the tree type that will be planted."
    ),
    .generate_detailed(output_values)
  )

  general_text <- .generate_general_info(MODEL_CONFIG)

  # Model info to be added at end
  end_text <- div(
    generate_version_and_last_update(),
    generate_timestamp()
  )

  return(
    Stack(
      class = "certificate",
      gap = 0,
      children = list(
        title_text,
        div(
          class = "certificate-body",
          result_headline_text,
          tags$hr(),
          general_text,
          tags$hr(),
          input_params_text,
          tags$hr(),
          result_long_text,
          tags$hr(),
          end_text
        )
      )
    )
  )
}

.generate_soil_info <- function(output_values, input_raw) {
  # check if topsoil present
  items <- list(
    paste0("The site is located at the grid reference ", strong(toupper(input_raw$osgb_grid_reference)), "."),
    paste0("The site will be planted with ", strong(tolower(input_raw$crop_type)), " tree species."),
    paste0("The soil-forming material texture is ", strong(tolower(input_raw$sfm_texture)), "."),
    paste0("The soil-forming material is classified as ", strong(tolower(input_raw$sfm_stone)), " stony."),
    paste0("The soil-forming preparation is ", strong(tolower(input_raw$sfm_prep)), ".")
  )

  if (output_values$inputs$topsoil_present) {
    items <- append(items, list(
      paste0("The topsoil material texture is ", strong(tolower(input_raw$topsoil_texture)), "."),
      paste0("The topsoil material is classified as ", strong(tolower(input_raw$topsoil_stone)), " stony."),
      paste0("The topsoil thickness range is ", strong(tolower(input_raw$topsoil_depth)), ".")
    ))
  } else {
    items <- append(items, list(
      "There is no existing or planned topsoil."
    ))
  }

  li_elements <- lapply(items, function(item) {
    tags$li(HTML(item))
  })

  # Wrap in tags$ul
  tags$ul(li_elements)
}

.generate_headline <- function(output_values) {
  if (output_values$inputs$topsoil_present) {
    if (output_values$outputs$SFM_required) {
      return(
        p(
          "A soil-forming material thickness of ",
          strong(.round_up_to_nearest(output_values$outputs$max_required_SFM_depth), " mm"),
          " is required to meet tree water requirements. This is in addition to the existing
        topsoil thickness of ",
          strong(.round_up_to_nearest(output_values$inputs$topsoil_depth), " mm"),
          ". The combined required thickness is ",
          strong(.round_up_to_nearest(output_values$outputs$max_total_depth), " mm.")
        )
      )
    } else {
      return(p("The projected rainfall is sufficient to meet tree water requirements.
      No additional soil-forming material is required."))
    }
  } else {
    if (output_values$outputs$SFM_required) {
      return(
        p(
          "A soil-forming material thickness of ",
          strong(.round_up_to_nearest(output_values$outputs$max_required_SFM_depth), " mm"),
          " is required to meet tree water requirements. No topsoil was included in this calculation."
        )
      )
    } else {
      return(p("The projected rainfall is sufficient to meet tree water requirements."))
    }
  }
}

.generate_detailed <- function(output_values) {
  if (output_values$outputs$SFM_required) {
    return(
      div(
        p("The model results for each climate projection period are recorded below:"),
        generate_scenario_table(output_values),
        p("The required soil-forming material thickness is the greatest required thickness across all projection periods.")
      )
    )
  }
  return(div(
    p("None of the climate scenarios predicted a requirement for additional soil-forming materials.")
  ))
}

.generate_general_info <- function(MODEL_CONFIG) {
  return(
    div(
      h3("General guidance"),
      p("It is recommended that the total soil thickness is at least 1500 mm to achieve stable rooting.
      Where the total required soil thickness is greater than 3000 mm, the site is unlikely to be suitable
      for tree planting.
      "),
      p("
    This document was generated by the Forest Research OpTS tool.
    It is intended to be used by planners and developers to estimate the amount of soil forming material (if any)
    required for woodland on the site. The tool can be run for this site or other sites by visiting: "),
      p(MODEL_CONFIG$tool_homepage)
    )
  )
}

.round_up_to_nearest <- function(x) {
  return(ceiling(x / MODEL_CONFIG$round_results_to_nearest) * MODEL_CONFIG$round_results_to_nearest)
}

#' @export
generate_error_message <- function(error_message) {
  return(
    div(
      class = "user-error-message",
      div(
        h2("There is a problem"),
        p(error_message)
      )
    )
  )
}

#' @export
generate_error_prompt <- function(error_message) {
  return(
    div(
      class = "user-error-prompt",
      p(error_message)
    )
  )
}

#' @export
generate_version_and_last_update <- function() {
  return(p(strong(
    "Software Version ", MODEL_CONFIG$release_version,
    " (last updated ", format(as.POSIXct(MODEL_CONFIG$last_commit, format = "%Y-%m-%d %H:%M:%S"), "%d %B, %Y)")
  )))
}

#' @export
generate_homepage_link <- function() {
  return(
    a("Forest Research OpTS Tool guidance (opens in new window)",
      href = MODEL_CONFIG$tool_homepage,
      target = "_blank"
    )
  )
}

#' @export
generate_homepage_url <- function() {
  return(MODEL_CONFIG$tool_homepage)
}

#' @export
generate_OSGB_tool_link <- function() {
  return(
    a("British National Grid (opens in new window)",
      href = "https://britishnationalgrid.uk/",
      target = "_blank"
    )
  )
}

#' @export
generate_timestamp <- function() {
  # Get current date, time, and time zone
  current_time <- format(Sys.time(), "%d %B, %Y %H:%M:%S %Z")

  # Create bold message using strong()
  return(p(strong(paste("This report was generated", current_time))))
}

# Function to generate an HTML table for R Shiny
generate_scenario_table <- function(output_values) {
  # Generate the table header
  table_header <- tags$tr(
    style = "border-bottom: 1px solid black;",
    tags$th("Projection Period", scope = "col", style = "padding-right: 10px;"),
    tags$th("Growing Period Rainfall (mm/year)", scope = "col", style = "padding-right: 10px;"),
    tags$th("Required SFM Thickness (mm)", scope = "col", style = "padding-right: 10px;")
  )

  # Generate the table rows
  table_rows <- lapply(names(output_values$outputs$required_SFM_depth), function(scenario) {
    tags$tr(
      tags$td(scenario),
      tags$td(output_values$inputs$average_summer_rainfall[[scenario]]),
      tags$td(.round_up_to_nearest(output_values$outputs$required_SFM_depth[[scenario]]))
    )
  })

  # Combine header and rows into the full table
  html_table <- tags$table(
    tags$thead(
      table_header
    ),
    tags$tbody(
      do.call(tagList, table_rows)
    )
  )

  return(p(html_table))
}
