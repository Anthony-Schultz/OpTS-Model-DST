# Run the Soil Depth Model
#
# This function calculates the total profile depth and other outputs related to water
# availability based on site conditions, soil properties, and rainfall inputs.
#
# The function performs the following steps:
# 1. If topsoil is present, calculates the available water in the topsoil. Otherwise,
#    sets the available water, topsoil depth to zero.
# 2. Calculates the effective summer rainfall based on the retention factor.
# 3. Computes additional water requirements based on transpiration, rainfall, and
#    topsoil available water.
# 4. Determines the required SFM depth to meet additional water requirements if needed.
# 5. Calculates the total profile depth, summing topsoil depth and required SFM depth.


#' @export
predict <- function(
    topsoil_TPD,
    topsoil_stone_fraction,
    topsoil_depth,
    transpiration,
    average_summer_rainfall, # Named list of scenarios
    rainfall_retention_factor,
    sfm_TPD,
    sfm_stone_fraction) {
  # Initialize topsoil-related values
  if (topsoil_depth > 0) {
    topsoil_available_water <- calculate_topsoil_available_water(
      topsoil_TPD,
      topsoil_stone_fraction,
      topsoil_depth
    )
    topsoil_present <- TRUE
  } else {
    topsoil_available_water <- 0
    topsoil_present <- FALSE
  }

  # Initialize output lists
  effective_summer_rainfall <- list()
  additional_water_requirement <- list()
  required_SFM_depth <- list()
  total_depth <- list()

  # Iterate over each rainfall scenario
  for (scenario in names(average_summer_rainfall)) {
    # Calculate effective summer rainfall for the scenario
    effective_summer_rainfall[[scenario]] <- calculate_effective_summer_rainfall(
      average_summer_rainfall[[scenario]],
      rainfall_retention_factor
    )

    # Calculate additional water requirement for the scenario
    additional_water_requirement[[scenario]] <- calculate_additional_water_requirement(
      transpiration,
      effective_summer_rainfall[[scenario]],
      topsoil_available_water
    )

    # Calculate required SFM depth for the scenario
    if (additional_water_requirement[[scenario]] > 0) {
      required_SFM_depth[[scenario]] <- calculate_required_SFM_depth(
        additional_water_requirement[[scenario]],
        sfm_TPD,
        sfm_stone_fraction
      )
    } else {
      required_SFM_depth[[scenario]] <- 0
    }

    # Calculate total profile depth for the scenario
    total_depth[[scenario]] <- calculate_total_depth(
      topsoil_depth,
      required_SFM_depth[[scenario]]
    )
  }

  # Return inputs and outputs
  return(
    list(
      inputs = list(
        topsoil_present = topsoil_present,
        topsoil_TPD = topsoil_TPD,
        topsoil_stone_percent = topsoil_stone_fraction * 100,
        topsoil_depth = topsoil_depth,
        transpiration = transpiration,
        average_summer_rainfall = average_summer_rainfall,
        rainfall_retention_factor = rainfall_retention_factor,
        sfm_TPD = sfm_TPD,
        sfm_stone_percent = sfm_stone_fraction * 100
      ),
      outputs = list(
        topsoil_available_water = topsoil_available_water,
        effective_summer_rainfall = effective_summer_rainfall,
        additional_water_requirement = additional_water_requirement,
        required_SFM_depth = required_SFM_depth,
        max_required_SFM_depth = max(unlist(required_SFM_depth)),
        SFM_required = max(unlist(required_SFM_depth)) > 0,
        total_depth = total_depth,
        max_total_depth = max(unlist(total_depth))
      )
    )
  )
}

#' @export
calculate_topsoil_available_water <- function(
    topsoil_TPD,
    topsoil_stone_fraction,
    topsoil_depth) {
  return(topsoil_TPD * (1 - topsoil_stone_fraction) * topsoil_depth)
}

#' @export
calculate_effective_summer_rainfall <- function(
    average_summer_rainfall,
    rainfall_retention_factor) {
  return(average_summer_rainfall * rainfall_retention_factor)
}

#' @export
calculate_additional_water_requirement <- function(
    transpiration,
    effective_summer_rainfall,
    adjusted_topsoil_available_water) {
  awr <- transpiration - effective_summer_rainfall - adjusted_topsoil_available_water
  # truncates the result at 0 to avoid negative values
  if (awr < 0) {
    return(0)
  } else {
    return(awr)
  }
}

#' @export
calculate_required_SFM_depth <- function(
    additional_water_requirement,
    sfm_TPD,
    sfm_stone_fraction) {
  # The 10x multiplier has been removed as no current rationale for treating
  # topsoil differently from SFMs in this part of the model.
  # Note that correction of the input AWC_texture_packing density is done by
  # dividing the input values by 10. THis applies the correction to both the
  # topsoil and the SFM. This step happens in the IO submodule.
  # Original version:
  # return((10 * additional_water_requirement) / (sfm_TPD * (1 - sfm_stone_fraction)))
  # Corrected version:
  return(additional_water_requirement / (sfm_TPD * (1 - sfm_stone_fraction)))
}

#' @export
calculate_total_depth <- function(
    topsoil_depth,
    required_SFM_depth) {
  return(topsoil_depth + required_SFM_depth)
}
