box::use(yaml, here, utils[read.csv])

read_config_yaml <- function() {
  # Define the file path relative to the project root
  file_path <- CONFIG_PATH

  # Validate the file exists
  if (!file.exists(file_path)) {
    stop("Configuration file not found at: ", file_path)
  }

  # Parse and return the YAML configuration as a named list
  config <- yaml::yaml.load_file(file_path)
  return(config)
}


read_awc_data <- function() {
  # Define the file path relative to the project root
  file_path <- here$here(MODEL_CONFIG$soil_texture_path)

  # Check if the file exists
  if (!file.exists(file_path)) {
    stop("Texture Packing Density data not found at path: ", file_path)
  }

  # Read the CSV file
  data <- read.csv(file_path, stringsAsFactors = FALSE)

  # suspect that these values are available water content in cm/m
  # do not correct here, correct in parsing

  # return(data * 10)
  return(data)
}

#' @export
get_tpd_fraction <- function(
    soil_texture_class, # e.g. Clay, Sandy clay, etc.
    soil_prep # e.g. topsoil, medium etc.
    ) {
  soil_texture_class_ <- MODEL_CONFIG$soil_texture_classes[[soil_texture_class]]
  out_column <- MODEL_CONFIG$soil_texture_columns[[soil_prep]]
  name_column <- MODEL_CONFIG$soil_texture_name_column
  # suspect AWC_texture_... is in incorrect units or scaling and this is why there
  # is a 10x multiplier in the model logic. The multiplier has been removed and the correction is
  # applied here - TPD is texture packing density and is in the file as a percentage. Convert to
  # fraction by divide 100.
  return(as.numeric(TPD_LOOKUP[TPD_LOOKUP[name_column] == soil_texture_class_, out_column]) / 100)
  # return(as.numeric(TPD_LOOKUP[TPD_LOOKUP[name_column] == soil_texture_class_, out_column]))
}

CONFIG_PATH <- here::here("app/logic/config.yml")

#' @export
MODEL_CONFIG <- read_config_yaml()

#' @export
TPD_LOOKUP <- read_awc_data()
