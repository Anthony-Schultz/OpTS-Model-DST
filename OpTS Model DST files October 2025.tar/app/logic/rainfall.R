# Purpose: return rainfall from position
# Import required libraries using box::use
box::use(
  terra, # For raster data processing
  app / logic / io[MODEL_CONFIG],
  here
)

# Define the Module
# Load the raster from MODEL_CONFIG
raster_path <- here$here(MODEL_CONFIG$rainfall_data_raster_path)
# print(raster_path)
if (is.null(raster_path) || !file.exists(raster_path)) {
  stop(paste("Raster file path is invalid or does not exist: ", raster_path))
}

raster_data <- terra$rast(raster_path)

# Function to check if a point is within raster bounds
is_point_inside <- function(x, y) {
  raster_extent <- terra$ext(raster_data)
  x >= raster_extent$xmin && x <= raster_extent$xmax &&
    y >= raster_extent$ymin && y <= raster_extent$ymax
}

# function to check if lat/lon is inside the raster bounds after reprojection
#' @export
is_lat_lon_inside <- function(lon, lat) {
  if (!is.numeric(lon) || !is.numeric(lat)) {
    return(FALSE)
  }

  # Create a point in EPSG:4326 (WGS84)
  point <- terra::vect(matrix(c(lon, lat), ncol = 2), crs = "EPSG:4326")

  # Reproject the point to EPSG:27700 (British National Grid)
  point_projected <- terra::project(point, "EPSG:27700")

  # Extract the coordinates of the projected point
  coords <- terra::geom(point_projected)[, c("x", "y")]

  # Check if the point is inside the raster bounds
  return(is_point_inside(coords[1], coords[2]))
}

# Function to get multi-band raster values by projected coordinates
#' @export
get_rainfall_by_projected <- function(x, y) {
  if (!is.numeric(x) || !is.numeric(y)) {
    return(NA)
  }
  if (!is_point_inside(x, y)) {
    return(NA)
  }

  point <- terra$vect(matrix(c(x, y), ncol = 2), crs = "EPSG:27700")

  # Extract values for all bands
  values <- terra$extract(raster_data, point)

  # Check if values are available
  if (is.null(values)) {
    return(NA)
  }

  # Get band names from MODEL_CONFIG
  band_names <- MODEL_CONFIG$rainfall_data_raster_bands

  # Ensure the number of bands in raster matches the band names provided
  if (length(band_names) != ncol(values) - 1) {
    stop("The number of bands in the raster does not match the number of band names.")
  }

  # Create a named list with the band names and corresponding values
  result <- list()
  for (i in 1:length(band_names)) {
    result[[band_names[i]]] <- values[, i + 1] # Skip the first column which is the point identifier
  }

  return(result)
}

# Function to get multi-band raster values by longitude and latitude
#' @export
get_rainfall_by_latlon <- function(lon, lat) {
  if (!is.numeric(lon) || !is.numeric(lat)) {
    return(NA)
  }

  # Create a point in EPSG:4326
  point <- terra::vect(matrix(c(lon, lat), ncol = 2), crs = "EPSG:4326")

  # Reproject the point to EPSG:27700
  point_projected <- terra::project(point, "EPSG:27700")

  # Extract the coordinates of the projected point
  coords <- terra::geom(point_projected)[, c("x", "y")]

  # Check if the point is inside the raster bounds
  if (!is_point_inside(coords[1], coords[2])) {
    return(NA)
  }

  # Extract values for all bands
  values <- terra::extract(raster_data, point_projected)

  # Check if values are available
  if (is.null(values)) {
    return(NA)
  }

  # Get band names from MODEL_CONFIG
  band_names <- MODEL_CONFIG$rainfall_data_raster_bands

  # Ensure the number of bands in raster matches the band names provided
  if (length(band_names) != ncol(values) - 1) {
    stop("The number of bands in the raster does not match the number of band names.")
  }

  # Create a named list with the band names and corresponding values
  result <- list()
  for (i in 1:length(band_names)) {
    result[[band_names[i]]] <- values[, i + 1] # Skip the first column which is the point identifier
  }

  return(result)
}
