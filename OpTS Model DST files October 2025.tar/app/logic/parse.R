# converts categorical variables to numeric inputs
box::use(
  app / logic / io[get_tpd_fraction, MODEL_CONFIG],
  app / logic / osgb[osg_parse],
  app / logic / rainfall[is_lat_lon_inside, get_rainfall_by_projected]
)

#' @export


#' @export
parse_inputs <- function(
    osgb_grid_reference,
    topsoil_depth,
    topsoil_texture,
    topsoil_stone,
    sfm_texture,
    sfm_stone,
    sfm_prep,
    crop_type) {
  # check for any nulls in required params
  if (is.null(osgb_grid_reference)) {
    stop("Grid ref is required")
  }

  if (is.null(topsoil_depth)) {
    stop("topsoil is required")
  }

  if (is.null(sfm_texture)) {
    stop("sfm_texture is required")
  }

  if (is.null(sfm_stone)) {
    stop("sfm_stone is required")
  }

  if (is.null(crop_type)) {
    stop("crop_type is required")
  }

  if (is.null(sfm_prep)) {
    stop("sfm_prep is required")
  }

  # parse coords
  coords <- osg_parse(osgb_grid_reference, "BNG")

  return <- list(
    transpiration = MODEL_CONFIG$transpiration_rates[[crop_type]],
    # convert topsoil depth categorical classes to midpoint float
    topsoil_depth = MODEL_CONFIG$top_thick_levels[[topsoil_depth]],
    # retrieve Texture Packing Density values for topsoil
    topsoil_TPD = get_tpd_fraction(topsoil_texture, "topsoil"),
    # convert topsoil stone fraction class to midpoint float
    topsoil_stone_fraction = MODEL_CONFIG$stone_levels[[topsoil_stone]],
    # retrieve the Texture Packing Density values for the SFM
    sfm_TPD = get_tpd_fraction(sfm_texture, MODEL_CONFIG$soil_prep_levels[[sfm_prep]]),
    # convert SFM stone fraction class to midpoint float
    sfm_stone_fraction = MODEL_CONFIG$stone_levels[[sfm_stone]],
    # retrieve parameter from config specific to crop_type
    rainfall_retention_factor = MODEL_CONFIG$rainfall_retention_factor[[crop_type]],
    # summer rainfall
    average_summer_rainfall = get_rainfall_by_projected(x = coords$x, y = coords$y)
  )
}

#' @export
parse_model_config_options <- function(config_section_name, prepend_values = NULL) {
  config_section <- MODEL_CONFIG[[config_section_name]]
  # Generate the main list based on config_section
  out_2 <- lapply(names(config_section), function(key) {
    list(key = key, text = key) #
  })

  # If there are values to prepend, add them at the beginning
  if (!is.null(prepend_values)) {
    prepend_list <- lapply(prepend_values, function(value) {
      list(key = value, text = value) #
    })
    out_2 <- c(prepend_list, out_2)
  }

  return(out_2)
}

#' @export
validate_multiple_selection <- function(selection) {
  if (is.null(selection)) {
    return("Select ONE option.")
  }
  return(NULL)
}

#' @export
validate_topsoil_options <- function(selection, topsoil_depth) {
  if (is.null(selection)) {
    return("Select ONE option.")
  }

  if (is.null(topsoil_depth)) {
    return("Something went wrong.")
  }

  if (topsoil_depth != "No topsoil" & selection == "No topsoil") {
    return("Because you selected a topsoil depth, select a valid topsoil property.")
  }

  return(NULL)
}

#' @export
validate_osgb_input <- function(osgb_input) {
  # Check if input is NULL
  if (is.null(osgb_input)) {
    return("Enter a six-digit grid reference.")
  }

  # Attempt to parse OSGB input and catch errors
  coords <- tryCatch(
    {
      osg_parse(osgb_input, "WGS84") # Parse OSGB input
    },
    error = function(e) {
      return(e$message) # Return error message as a string
    }
  )
  # If coords is a string (an error message), return it
  if (is.character(coords)) {
    return(coords)
  }
  # Check if the coordinates are inside the valid range
  if (!is_lat_lon_inside(coords$x, coords$y)) {
    return("There is no rainfall data for this position.")
  }

  # If all validations pass, return NULL (or a success message if desired)
  return(NULL)
}
