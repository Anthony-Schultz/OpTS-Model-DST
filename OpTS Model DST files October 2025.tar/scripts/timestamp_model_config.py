#!/usr/bin/env python3

import os
import time


def update_config_file(config_file):
    """
    Updates the 'last_commit' key in the given YAML config file. If the key exists,
    it is overwritten. If the file or key doesn't exist, an error is raised.
    """

    # Check if the file exists
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"Error: Config file does not exist at path: {config_file}")

    # Read the existing file
    with open(config_file, "r") as file:
        lines = file.readlines()

    # Get the current timestamp
    current_time = time.strftime("%Y-%m-%d %H:%M:%S")

    # Update or append the `last_commit` key
    found_key = False
    updated_lines = []
    for line in lines:
        if line.startswith("last_commit:"):
            updated_lines.append(f"last_commit: \"{current_time}\"\n")
            found_key = True
        else:
            updated_lines.append(line)

    if not found_key:
        updated_lines.append(f"last_commit: \"{current_time}\"\n")

    # Write the updated content back to the file
    with open(config_file, "w") as file:
        file.writelines(updated_lines)

    print(f"Updated 'last_commit' in {config_file}")


if __name__ == "__main__":
    # Path to the config file
    config_file_path = "app/logic/config.yml"

    try:
        update_config_file(config_file_path)
    except FileNotFoundError as e:
        print(e)
        exit(1)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        exit(1)
